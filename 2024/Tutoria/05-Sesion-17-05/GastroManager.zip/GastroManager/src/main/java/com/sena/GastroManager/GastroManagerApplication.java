package com.sena.GastroManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GastroManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(GastroManagerApplication.class, args);
	}

}
