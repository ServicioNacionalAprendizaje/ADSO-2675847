package com.sena.GastroManager.Dto;

public interface IPersonDto {

    String gettypeDocument();
    String getDocument();
    String getFirstName();
    String getLastName();
    String getPhone();
    String getAddress();
}
