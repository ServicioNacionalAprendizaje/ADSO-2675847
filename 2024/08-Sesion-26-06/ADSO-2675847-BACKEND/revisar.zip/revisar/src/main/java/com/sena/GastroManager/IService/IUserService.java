package com.sena.GastroManager.IService;

import com.sena.GastroManager.Entity.User;

public interface IUserService extends IBaseService<User>{
}
